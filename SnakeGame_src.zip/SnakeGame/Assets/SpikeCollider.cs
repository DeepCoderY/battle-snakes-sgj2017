﻿using UnityEngine;
using System.Collections;

public class SpikeCollider : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter2D(Collider2D collider) {
		SnakeControll scOpp = null;
		scOpp = collider.gameObject.GetComponent<SnakeControll>();
		Snake oppSnake = null;

		if (scOpp == null) {
			oppSnake = collider.gameObject.GetComponentInParent<Snake> ();
		} else {
			oppSnake = scOpp.gameObject.GetComponentInParent<Snake> ();
		}

		if (oppSnake == null) {
			return;
		}
		
		oppSnake.Hit (collider.transform);

	}
}
