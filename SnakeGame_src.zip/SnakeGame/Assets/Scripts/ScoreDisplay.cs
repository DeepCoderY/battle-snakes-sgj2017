﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ScoreDisplay : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Text t = GetComponent<Text> ();
		t.text = "Score: " + ScoreKeeper.score.ToString ();
		ScoreKeeper.score = 0;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
