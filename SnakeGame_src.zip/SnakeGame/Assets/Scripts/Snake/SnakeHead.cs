﻿using UnityEngine;
using System.Collections;

public class SnakeControll : MonoBehaviour {

	public float WhipCooldown = 0.6f;
	public float WhipDuration = 0.45f;

	public float Speed = 55f;
	private SnakeMove mover;
	private Snake snake;
	private float lastWhip;
	private bool whipping = false;

	private Controlls controls;

	// Use this for initialization
	void Start () {
		this.mover = this.transform.parent.GetComponent<SnakeMove> ();
		this.controls = GameObject.Find("GameController").GetComponent<Controlls>();
		this.snake = this.transform.parent.GetComponent<Snake> ();
	}

	public bool IsWhipping() {
		return this.whipping;
	}

	public void EatBug() {
		this.snake.ChangeHealth (+45f);
		this.snake.PlayEatSound (this.transform);
	}
	
	// Update is called once per frame
	void Update () {
		float inc = (Speed - (this.snake.GetSize() * 15f))  * Time.deltaTime;
		Controller (inc);
		//Keyboard (inc);
	}

	void Controller(float inc) {


		if (!whipping) {
			if (Input.GetButtonDown(controls.Whip[snake.PlayerId]) || Input.GetKeyDown(KeyCode.Space)) {
				whipping = true;
				lastWhip = Time.time;
				this.snake.PlayWhipSound(this.transform);
			}
		}

		if (Input.GetButton ("Fire2")) {
			//this.snake.ChangeHealth(+20f);
		}

		if (whipping) {
			if (Time.time <= (this.lastWhip + WhipDuration)) {
				this.mover.Whip ();
			}
			if (Time.time >= (this.lastWhip + WhipCooldown)) {
				whipping = false;
			}
		} 

		if (Input.GetAxis (controls.HAxis [snake.PlayerId]) != 0 || Input.GetAxis (controls.VAxis [snake.PlayerId]) != 0) {
			float xInc = Input.GetAxis (controls.HAxis [snake.PlayerId]) * inc;
			float yInc =Input.GetAxis (controls.VAxis [snake.PlayerId]) * inc;


			float newX = this.transform.position.x + xInc;
			newX = Mathf.Clamp(newX, -720f, 750f);
			float newY = this.transform.position.y + yInc;
			newY = Mathf.Clamp(newY, -400f, 370f);
			Vector3 newPos = new Vector3(newX, newY, 0f);


			Vector3 vectorToTarget = newPos - this.transform.position;
			float angle = (Mathf.Atan2(vectorToTarget.y, vectorToTarget.x) * Mathf.Rad2Deg) - 90f;
			Quaternion q = Quaternion.AngleAxis(angle, Vector3.forward);
			this.transform.rotation = Quaternion.Slerp(transform.rotation, q, Time.deltaTime * 10f);
			this.transform.position = newPos;
			
		}
	}

	void Keyboard(float inc) {
		float xPos = this.transform.position.x;
		float yPos = this.transform.position.y;
		if (Input.GetKey (KeyCode.UpArrow)) {
			//yPos += inc;
			float angle = this.transform.eulerAngles.z;
			float theta = Mathf.Deg2Rad * angle;
			
			float x = Mathf.Cos(theta);
			float y = Mathf.Sin(theta);
		
			xPos += x * inc;
			yPos += y * inc;
		}
		if (Input.GetKey (KeyCode.DownArrow)) {
			//yPos -= inc;
		}
		if (Input.GetKey (KeyCode.LeftArrow)) {
			//xPos -= inc;
			this.transform.Rotate(Vector3.forward * Time.deltaTime * 180f, Space.Self);
			//this.transform.RotateAround(this.transform.position, new Vector3(0, 0, 1), 90 * Time.deltaTime);
		}
		if (Input.GetKey (KeyCode.RightArrow)) {
			//xPos += inc;
			this.transform.Rotate(Vector3.back * Time.deltaTime * 180f, Space.Self);
		}
		this.transform.position = new Vector3 (xPos, yPos, 0f);
		//Debug.Log (string.Format("{0};{1}", xPos, yPos)); 
	}
}
