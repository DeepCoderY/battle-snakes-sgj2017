﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class Snake : MonoBehaviour {

	public int PlayerId;
	public int SectionCount = 20;
	public float SegmentSpacing = 10f;
	public float SnakeSpeed = 100f;
	public AudioClip WhipSound;
	public AudioClip HitSound1;
	public AudioClip HitSound2;
	public AudioClip EatSound1;
	public AudioClip EatSound2;
	public AudioClip HissSound;
	public float Volume;

	// ========== PREFABS ============
	public GameObject sectionPrefab;
	public GameObject headPrefab;
	public GameObject tailPrefab;
	public GameObject hitEffectPrefab;

	private Health Health;
	private GameObject Head;
	private GameObject Tail;
	private List<GameObject> Sections = new List<GameObject>();

	private SnakeMove snakeMover;
	private SnakeControll control;

	// Use this for initialization
	void Start () {
		if (this.sectionPrefab == null)
			this.sectionPrefab = Resources.Load("Prefabs/SnakeSection", typeof(GameObject)) as GameObject;

		if (this.headPrefab == null)
			this.headPrefab = Resources.Load("Prefabs/SnakeHead", typeof(GameObject)) as GameObject;

		if (this.tailPrefab == null)
			this.tailPrefab = Resources.Load("Prefabs/SnakeTail", typeof(GameObject)) as GameObject;

		if (this.hitEffectPrefab == null)
			this.hitEffectPrefab = Resources.Load("Prefabs/HitEffect", typeof(GameObject)) as GameObject;

		// Head INIT
		this.Health = this.gameObject.AddComponent<Health> ();
		this.Head = Instantiate (this.headPrefab) as GameObject;
		this.Head.transform.SetParent(this.transform);
		this.Head.layer = LayerMask.NameToLayer("Player" + PlayerId);
		this.Head.transform.position = this.transform.position;
		this.control = this.Head.gameObject.AddComponent<SnakeControll> ();
		this.control.Speed = SnakeSpeed;

		float y = this.Head.transform.position.y;
		// Sections INIT
		for (int i = 0; i < SectionCount; i++) {
			GameObject section = Instantiate (this.sectionPrefab) as GameObject;
			section.transform.SetParent (this.transform);
			section.transform.position = this.Head.transform.position;
			section.layer = LayerMask.NameToLayer("Player" + PlayerId);
			this.Sections.Add(section);
		}

		// Tail INIT
		this.Tail = Instantiate (this.tailPrefab) as GameObject;
		this.Tail.transform.SetParent(this.transform);
		this.Tail.transform.position = this.Head.transform.position;
		this.Tail.layer = LayerMask.NameToLayer("Player" + PlayerId);

		this.snakeMover = this.gameObject.AddComponent<SnakeMove> ();
		this.snakeMover.Init(this.Head, this.Tail, this.Sections.ToArray (), this.SegmentSpacing);
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public int GetSize() {
		return 2 + this.Sections.Count;
	}

	public void PlayWhipSound(Transform at) {
		AudioSource.PlayClipAtPoint (this.WhipSound, at.position, this.Volume);
	}

	public void PlayEatSound(Transform at) {
		float rnd = Random.Range (0f, 1f);
		if (rnd > 0.5) {
			AudioSource.PlayClipAtPoint (this.EatSound1, at.position, this.Volume);
		} else {
			AudioSource.PlayClipAtPoint (this.EatSound2, at.position, this.Volume);
		}
	}

	public void PlayHissSound(Transform at) {
		AudioSource.PlayClipAtPoint (this.HissSound, at.position, this.Volume);
	}

	public void PlayHitSound(Transform at) {
		float rnd = Random.Range (0f, 1f);
		if (rnd > 0.5) {
			AudioSource.PlayClipAtPoint (this.HitSound1, at.position, this.Volume);
		} else {
			AudioSource.PlayClipAtPoint (this.HitSound2, at.position, this.Volume);
		}
	}

	public bool IsWhipping() {
		return this.control.IsWhipping ();
	}

	public void Hit(Transform at) {
		this.ChangeHealth(-20f);
		this.PlayHitSound(at);
		Instantiate (hitEffectPrefab, at.position, Quaternion.identity);
	}

	public float GetHealth() {
		return this.Health.GetHealth ();
	}
	public void HeadCollision(GameObject with) {
		// either removes health or adds modifier
		//ChangeHealth(+20f);

	}

	public void SectionCollision(GameObject whit) {
		// removes health
		//ChangeHealth(-10f);

	}

	public void ChangeHealth(float amount) {
		this.Health.Change (amount);
		int total = this.Health.HealthSections (5 * this.SectionCount);
		int sections =  total - this.Sections.Count;
		//Debug.Log ("Sections to have: " + total);
		if (sections > 0) {
			for (int i = 0; i < sections; i++) {
				GameObject section = Instantiate (this.sectionPrefab) as GameObject;
				section.transform.SetParent (this.transform);
				section.transform.position = this.Tail.transform.position;
				section.layer = LayerMask.NameToLayer("Player" + PlayerId);
				this.Sections.Add (section);
				this.snakeMover.AddNew(section.transform);
			}
		} else {
			if (total >= 2) { 
			for (int i = 0; i < -sections; i++)
			{
				GameObject section = this.Sections.LastOrDefault();
				if (section != null) {
					this.Sections.RemoveAt(this.Sections.Count - 1);
					this.Tail.transform.position = section.transform.position;
					this.snakeMover.RemoveLast();
					Destroy(section);
				}
			}
			}
		}
	}
}
