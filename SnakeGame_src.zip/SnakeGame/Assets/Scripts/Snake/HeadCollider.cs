﻿using UnityEngine;
using System.Collections;

public class HeadCollider : MonoBehaviour {

	private Snake snake;
	
	// Use this for initialization
	void Start () {
		this.snake = this.GetComponentInParent<Snake> ();
	}
	
	void OnTriggerEnter2D(Collider2D collider) {
		if (collider.gameObject.layer != this.gameObject.layer) {
			Debug.Log ("Head collided:" + collider.name);
		} 
	}
}
