﻿using UnityEngine;
using System.Collections;

public class Health : MonoBehaviour {

	private float health = 200;
	private float max = 1000f;

	public void SetMax(float max) {
		this.max = max;
	}

	public void SetHealth(float hp) {
		this.health = hp;
	}

	public float GetHealth() {
		return this.health;
	}

	public void Change(float amount) {
		float was = this.health;
		this.health = Mathf.Clamp (this.health + amount, 0, max);
		Debug.Log (string.Format("HP changed: {0} -> {1}", was, health));
	}

	public float Percentage() {
		return (this.health / this.max);
	}

	public int HealthSections(int max) {
		return (int)Mathf.Floor(Percentage () * (float)max);
	}

	public bool IsDead() {
		if (this.health <= 0) {
			return true;
		} else {
			return false;
		}
	}

}
