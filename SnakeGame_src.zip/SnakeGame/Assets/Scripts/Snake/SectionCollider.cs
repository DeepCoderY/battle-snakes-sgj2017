﻿using UnityEngine;
using System.Collections;

public class SectionCollider : MonoBehaviour {

	private Snake snake;

	// Use this for initialization
	void Start () {
		this.snake = this.GetComponentInParent<Snake> ();
	}
	
	void OnTriggerEnter2D(Collider2D collider) {
		SnakeControll scOpp = null;
		scOpp = collider.gameObject.GetComponent<SnakeControll>();
		Snake oppSnake = null;
		if (scOpp != null) {
			oppSnake = scOpp.gameObject.GetComponentInParent<Snake> ();
		}
		Snake mySnake = this.gameObject.GetComponentInParent<Snake>();

		if (mySnake == null || oppSnake == null) {
			return;
		}

		if (collider.gameObject.name.Contains("Tail") ||
		    collider.gameObject.name.Contains ("Head") ||
		 	collider.gameObject.name.Contains ("Section")) {
			Debug.Log("Section+Head collided:" + collider.name);

			if (mySnake.IsWhipping()) {
				oppSnake.Hit(collider.transform);
			} 

			if (oppSnake.IsWhipping()) {
				mySnake.Hit(collider.transform);
			}
			return;
		}
	}
}
