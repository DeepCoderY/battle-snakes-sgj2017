﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SnakeMove : MonoBehaviour {

	private Transform head;
	private Transform tail;
	private List<Transform> segments;
	private float segmentDistance;

	private float xMin;
	private float xMax;
	
	// Use this for initialization
	void Start () {

	}
	public void Init(GameObject head, GameObject tail, GameObject[] sections, float segmentDistance) {
		this.head = head.transform;
		this.segments = new List<Transform> ();
		for (int i=0; i<sections.Length; i++) {
			this.segments.Add( sections[i].transform);
		}
		this.segmentDistance = segmentDistance;
		this.tail = tail.transform;
	}

	public void RemoveLast() {
		this.segments.RemoveAt (this.segments.Count - 1);
	}

	public void AddNew(Transform segment) {
		this.segments.Add (segment);
	}

	void Update() {
		Move ();
	}

	void Move() {
		Transform prevBodyPart = this.head;
		Transform curBodyPart = null;
		Vector3 distance = new Vector3 (0f, 0f, 0f);
		float angle;
		Quaternion q;
		for(int i = 0; i < segments.Count; i++)
		{
		 	curBodyPart = segments[i];
			distance = curBodyPart.position - prevBodyPart.position;
			if (distance.magnitude * 0.05f > segmentDistance) {
				curBodyPart.position = Vector3.Lerp( curBodyPart.position, 
				                                     prevBodyPart.position, 
				                                     0.25f);				
			}
			angle = (Mathf.Atan2(distance.normalized.y, distance.normalized.x) * Mathf.Rad2Deg) + 270f;
			q = Quaternion.AngleAxis(angle, Vector3.forward);
			curBodyPart.rotation = Quaternion.RotateTowards(curBodyPart.rotation, q, angle);
			prevBodyPart = curBodyPart;
		}
		// for tail
		curBodyPart = this.tail;
		
		distance = curBodyPart.position - prevBodyPart.position;
		if (distance.magnitude * 0.05f > segmentDistance) {
			
			curBodyPart.position = Vector3.Lerp( curBodyPart.position, 
			                                    prevBodyPart.position, 
			                                    0.25f); 
			
		}
		angle = (Mathf.Atan2(distance.normalized.y, distance.normalized.x) * Mathf.Rad2Deg) + 270f + 180f;
		q = Quaternion.AngleAxis(angle, Vector3.forward);
		curBodyPart.rotation = Quaternion.RotateTowards(curBodyPart.rotation, q, angle);
		 	
	}
	
	public void Whip()
	{
		//Debug.Log("Whip");
		Vector3 headVector = (segments [0].position - this.head.position);
		Vector3 headDirection = headVector.normalized;
		Transform curBodyPart = null;
		Transform prevBodyPart = null;

		for (int i = 1; i < segments.Count; i++) {
			curBodyPart = segments [i];
			prevBodyPart = segments [i - 1];
			curBodyPart.position = Vector3.Slerp (curBodyPart.position, 
			                                      prevBodyPart.position + (headDirection * segmentDistance * 20f),
			                                      Time.deltaTime * 40f);
		}

	    curBodyPart = this.tail;
		prevBodyPart = segments [segments.Count - 1];
		curBodyPart.position = Vector3.Slerp (curBodyPart.position, 
		                                      prevBodyPart.position + (headDirection * segmentDistance * 20f),
		                                      Time.deltaTime * 40f);
	}
}
