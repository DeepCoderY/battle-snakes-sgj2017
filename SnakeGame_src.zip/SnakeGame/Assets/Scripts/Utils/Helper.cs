﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace Jzargo
{
    public static class Helper
    {
        private static Random rnd = new Random(Environment.TickCount);

        /// <summary>
        /// Globally usable random generator.
        /// </summary>
        public static Random Rand
        {
            get
            {
                return rnd;
            }
        }

        /// <summary>
        /// Clamps a double value.
        /// </summary>
        /// <param name="val">Value.</param>
        /// <param name="min">Minimum.</param>
        /// <param name="max">Maximum.</param>
        /// <returns>Clamped value.</returns>
        public static double Clamp(double val, double min, double max)
        {
            return Math.Min(max, Math.Max(min, val));
        }


        /// <summary>
        /// Compares equality of two double values based on Epsilon.
        /// </summary>
        /// <param name="number1">Double number one.</param>
        /// <param name="number2">Double number two.</param>
        /// <returns>
        /// True if the difference is lesser than double epsilon.
        /// </returns>
        public static bool DoubleEquals(double number1, double number2)
        {
            return DoubleEquals(number1, number2, double.Epsilon);
        }

        /// <summary>
        /// Compares not equality of two double values based on Epsilon.
        /// </summary>
        /// <param name="number1">Double number one.</param>
        /// <param name="number2">Double number two.</param>
        /// <returns>
        /// False if the difference is lesser than double epsilon.
        /// </returns>
        public static bool DoubleNotEquals(double number1, double number2)
        {
            return !DoubleEquals(number1, number2);
        }

        /// <summary>
        /// Compares equality of two double values based on a given epsilon.
        /// </summary>
        /// <param name="number1">Double number one.</param>
        /// <param name="number2">Double number two.</param>
        /// <param name="epsilon">Epsilon value.</param>
        /// <returns>
        /// True if the difference is lesser than the given epsilon.
        /// </returns>
        public static bool DoubleEquals(double number1, double number2, double epsilon)
        {
            if (System.Math.Abs(number1 - number2) > epsilon)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Compares not equality of two double values based on a given epsilon.
        /// </summary>
        /// <param name="number1">Double number one.</param>
        /// <param name="number2">Double number two.</param>
        /// <param name="epsilon">Epsilon value.</param>
        /// <returns>
        /// False if the difference is lesser than the given epsilon.
        /// </returns>
        public static bool DoubleNotEquals(double number1, double number2, double epsilon)
        {
            return !DoubleEquals(number1, number2, epsilon);
        }

        public static double Covariance<T>(T[] a, T[] b)
        {
            Debug.Assert(a.Length == b.Length);

            double[] aDouble = a.Select(r => Convert.ToDouble(r)).ToArray();
            double[] bDouble = b.Select(r => Convert.ToDouble(r)).ToArray();

            double aMean = aDouble.Average();
            double bMean = bDouble.Average();

            double cov = 0.0;
            for (int i = 0; i < a.Length; i++)
            {
                cov += (aDouble[i] - aMean) * (bDouble[i] - bMean);
            }

            cov /= a.Length;

            return cov;
        }

        public static double Variance<T>(T[] a)
        {
            return Covariance<T>(a, a);
        }
        
        public static double StdDev<T>(T[] a)
        {
            return Math.Sqrt(Variance<T>(a));
        }

        public static double Correlation<T>(T[] a, T[] b)
        {
            return Covariance<T>(a, b) / StdDev<T>(a) / StdDev<T>(b);
        }

        // Deep clone
        public static T DeepClone<T>(this T a)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, a);
                stream.Position = 0;
                return (T)formatter.Deserialize(stream);
            }
        }
    }
}
