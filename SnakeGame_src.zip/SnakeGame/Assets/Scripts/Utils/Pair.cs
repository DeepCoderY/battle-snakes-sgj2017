namespace Jzargo
{
    /// <summary>
    /// Base class for pair objects.
    /// </summary>
    /// <typeparam name="T1">Type for the first element.</typeparam>
    /// <typeparam name="T2">Type for the second element.</typeparam>
    public class Pair<T1, T2>
    {
        private T1 one;
        private T2 two;

        /// <summary>
        /// Constructs an empty abstract pair.
        /// </summary>
        public Pair()
        {
            this.one = default(T1);
            this.two = default(T2);
        }

        /// <summary>
        /// Base class initialization.
        /// </summary>
        /// <param name="one">First value.</param>
        /// <param name="two">Second value.</param>
        public Pair(T1 one, T2 two)
        {
            this.one = one;
            this.two = two;
        }

        /// <summary>
        /// First element.
        /// </summary>
        public virtual T1 One
        {
            get
            {
                return this.one;
            }
            set
            {
                this.one = value;
            }
        }

        /// <summary>
        /// Second element.
        /// </summary>
        public virtual T2 Two
        {
            get
            {
                return this.two;
            }
            set
            {
                this.two = value;
            }
        }

        /// <summary>
        /// Equality check for inherited classes.
        /// </summary>
        /// <param name="obj">Other object.</param>
        /// <returns>True if equals.</returns>
        public override bool Equals(object obj)
        {
            if (!object.ReferenceEquals(obj, null))
            {
                if (obj.GetType() == typeof(Pair<T1, T2>))
                {
                    Pair<T1, T2> comp = obj as Pair<T1, T2>;
                    if (comp.one.Equals(this.one) && comp.two.Equals(this.two))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the hash code for the pair.
        /// </summary>
        /// <returns>Hash code.</returns>
        public override int GetHashCode()
        {
            int hash = 23;
            hash = hash * 31 + this.one.GetHashCode();
            hash = hash * 31 + this.two.GetHashCode();
            return hash;
        }

        public override string ToString()
        {
            return this.one.ToString() + "|" + this.two.ToString();
        }
    }
}
