﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KurtyHikerPro
{
    public class Assert
    {
        public static void True(bool expression)
        {
            if (!expression)
                throw new InvalidOperationException();
        }

        public static void Equal<T>(T val1, T val2)
        {
            if (!val1.Equals(val2))
                throw new InvalidOperationException();
        }

        public static void Equal(bool val1, bool val2)
        {
            if (val1 != val2)
                throw new InvalidOperationException();
        }

        public static void Equal(int val1, int val2)
        {
            if (val1 != val2)
                throw new InvalidOperationException();
        }
    }
}
