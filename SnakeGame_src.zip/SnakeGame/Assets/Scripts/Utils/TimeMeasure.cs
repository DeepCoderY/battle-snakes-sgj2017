﻿//------------------------------------------------------------
// <summary>
//   <copyright file="TimeMeasure.cs" company="Kurtyka">
//     Copyright (c) Balázs Kurtán. All rights reserved.
//   </copyright> 
//         
//               KTools Library 
//   
//     E-mail: balazs.kurtan@gmail.com
//   
//     The dll-s and the documentations are free to 
//     share and copy. However if one likes to get
//     support or the source code, please contact me.
//   
//     If you like the library, please support me to 
//     create more cool stuff.
//   
//   <author>Balázs Kurtán</author> 
// </summary>
//------------------------------------------------------------

namespace Jzargo
{
    using System.Diagnostics;

    /// <summary>
    /// Time and frequency measurer, its an extended stopwatch.
    /// Usually the stop and start are consumes ~2 ticks.
    /// </summary>
    public class TimeMeasure
    {
        private static TimeMeasure instance = new TimeMeasure();

        private Stopwatch stopwatch = new Stopwatch();

        /// <summary>
        /// Instance member of a time measurer.
        /// </summary>
        public static TimeMeasure Instance
        {
            get
            {
                return instance;
            }
            set
            {
                instance = value;
            }
        }

        /// <summary>
        /// Time of measure.
        /// </summary>
        public string ElaspedTime
        {
            get
            {
                return this.stopwatch.Elapsed.TotalMilliseconds.ToString("0.0000") + " ms";
            }
        }

        /// <summary>
        /// Gets the time in a double of millis.
        /// </summary>
        public double TotalMilliseconds
        {
            get
            {
                return this.stopwatch.Elapsed.TotalMilliseconds;
            }
        }

        /// <summary>
        /// Gets the time in a double of micros.
        /// </summary>
        public double TotalMicroseconds
        {
            get
            {
                return this.stopwatch.Elapsed.TotalMilliseconds * 1000;
            }
        }

        /// <summary>
        /// Gets the time in a double of nanos.
        /// </summary>
        public double TotalNanos
        {
            get
            {
                return this.stopwatch.Elapsed.TotalMilliseconds * 1000000;
            }
        }

        /// <summary>
        /// Gets the time in a double of seconds.
        /// </summary>
        public double TotalSeconds
        {
            get
            {
                return this.stopwatch.Elapsed.TotalSeconds;
            }
        }

        /// <summary>
        /// Gets the time in a double of minutes.
        /// </summary>
        public double TotalMinutes
        {
            get
            {
                return this.stopwatch.Elapsed.TotalMinutes;
            }
        }

        /// <summary>
        /// Gets the time in a double of hours.
        /// </summary>
        public double TotalHours
        {
            get
            {
                return this.stopwatch.Elapsed.TotalHours;
            }
        }

        /// <summary>
        /// Gets the time in a double of days.
        /// </summary>
        public double TotalDays
        {
            get
            {
                return this.stopwatch.Elapsed.TotalDays;
            }
        }

        /// <summary>
        /// Gets the measured frequency in Hertz.
        /// </summary>
        public double MeasuredFrequency
        {
            get
            {
                if (this.stopwatch.Elapsed.TotalMilliseconds > 0.0d)
                {
                    return 1000.0d / this.stopwatch.Elapsed.TotalMilliseconds;
                }
                else
                {
                    return 0.0d;
                }
            }
        }

        /// <summary>
        /// Creates and starts a new instance of TimeMeasurer.
        /// </summary>
        /// <returns>TimeMeasure instance.</returns>
        public static TimeMeasure StartOne()
        {
            TimeMeasure tm = new TimeMeasure();
            tm.Start();
            return tm;
        }

        /// <summary>
        /// Starts time measurement.
        /// </summary>
        public void Start()
        {
            this.stopwatch.Reset();
            this.stopwatch.Start();
        }

        /// <summary>
        /// Continues the measurement.
        /// </summary>
        public void Continue()
        {
            this.stopwatch.Start();
        }

        /// <summary>
        /// Stops time measuring.
        /// </summary>
        public void Stop()
        {
            this.stopwatch.Stop();
        }

        /// <summary>
        /// Resets the time measurement.
        /// </summary>
        public void Reset()
        {
            this.stopwatch.Reset();
        }

        /// <summary>
        /// Override to string method.
        /// </summary>
        /// <returns>Returns with textual time value.</returns>
        public override string ToString()
        {
            return this.ElaspedTime;
        }
    }
}
