﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Jzargo
{
    public class GaussianFunction
    {
        public double Sigma
        {
            get;
            set;
        }

        public double SigmaSquare
        {
            get
            {
                return this.Sigma * this.Sigma;
            }
        }

        public GaussianFunction() { }

        public GaussianFunction(double sigma)
        {
            this.Sigma = sigma;
        }

        public double Function(double x)
        {
            return Function(x, this.Sigma);
        }

        public double Function2D(double x, double y)
        {
            return Function2D(x, y, this.Sigma);
        }

        public double[] Kernel(int size)
        {
            return Kernel(size, this.Sigma);
        }

        public double[,] Kernel2D(int size)
        {
            return Kernel2D(size, this.Sigma);
        }

        public static double Function(double x, double sigma)
        {
            double sigsqr = sigma * sigma;
            return System.Math.Exp((x * x) / (-2.0 * sigsqr)) / System.Math.Sqrt(Math.PI * 2.0 * sigma);
        }

        public static double Function2D(double x, double y, double sigma)
        {
            double sigsqr = sigma * sigma;
            return System.Math.Exp(((x * x) + (y * y)) / (-2.0 * sigsqr)) / System.Math.Sqrt(Math.PI * 2.0 * sigma);
        }

        public static double[] Kernel(int size, double sigma)
        {
            if ((size < 3) || (size % 2 == 0))
                throw new ArgumentException("Kernel size should be at least 3, and the size shall be odd!");

            int r = size / 2;
            double[] kernel = new double[size];

            for (int x = -r, i = 0; i < size; x++, i++)
            {
                kernel[i] = Function(x, sigma);
            }

            return kernel;
        }

        public static double[,] Kernel2D(int size, double sigma)
        {
            if ((size < 3) || (size % 2 == 0))
                throw new ArgumentException("Kernel size should be at least 3, and the size shall be odd!");

            int r = size / 2;
            // kernel
            double[,] kernel = new double[size, size];

            // compute kernel
            for (int y = -r, i = 0; i < size; y++, i++)
            {
                for (int x = -r, j = 0; j < size; x++, j++)
                {
                    kernel[i, j] = Function2D(x, y, sigma);
                }
            }

            return kernel;
        }
    }
}
