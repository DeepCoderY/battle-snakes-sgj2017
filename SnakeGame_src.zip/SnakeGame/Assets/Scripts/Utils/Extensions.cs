﻿using System;
using System.Collections.Generic;

namespace Jzargo
{
    public static class ListExtensions
    {
        private static Random rng = new Random(Environment.TickCount);
        public static void Shuffle<T>(this IList<T> list)
        {
            var n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }

        public static T RandomSampling<T>(this IList<T> list)
        {
            if (list != null && list.Count > 0)
            {
                return list[rng.Next(0, list.Count)];
            }
            else
            {
                return default(T);
            }
        }

        public static bool IsEmpty<T>(this IList<T> list)
        {
            return list.Count == 0;
        }

        public static void AddFirst<T>(this IList<T> list, T element)
        {
            list.Insert(0, element);
        }

        public static void AddListed<K, V>(this IDictionary<K, List<V>> dict, K key, V value)
        {
            if (dict.ContainsKey(key))
            {
                dict[key].Add(value);
            }
            else
            {
                List<V> list = new List<V>();
                list.Add(value);
                dict.Add(key, list);
            }
        }

        public static void AddListed<K, V>(this IDictionary<K, HashSet<V>> dict, K key, V value)
        {
            if (dict.ContainsKey(key))
            {
                dict[key].Add(value);
            }
            else
            {
                HashSet<V> list = new HashSet<V>();
                list.Add(value);
                dict.Add(key, list);
            }
        }
    }
}
