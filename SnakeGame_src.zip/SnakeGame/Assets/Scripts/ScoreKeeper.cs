﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ScoreKeeper : MonoBehaviour {

	public static int score = 0;
	private Text text;

	void Start() {
		text = GetComponent<Text> ();
	}

	public void AddScore(int points) {
		score += points;
		text.text = score.ToString ();
	}

	public void Reset() {
		score = 0;
		text.text = score.ToString ();
	}
}
