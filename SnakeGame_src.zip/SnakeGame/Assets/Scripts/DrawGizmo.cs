﻿using UnityEngine;
using System.Collections;

public class DrawGizmo : MonoBehaviour {

	void OnDrawGizmos() {
		Gizmos.DrawWireCube(transform.position, new Vector3(Screen.width, Screen.height, 0));
	}
}
