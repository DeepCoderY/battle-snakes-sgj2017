﻿using UnityEngine;
using System.Collections;

public class CounterMove : MonoBehaviour {

	// Use this for initialization
	void Start () {
	}
	
	void OnTriggerEnter2D(Collider2D collider) {
		Debug.Log ("OnTriggerEnter2D");
		/* if (collider.rigidbody2D.tag == "Ball") {
			Vector3 distance = collider.transform.position - this.transform.position;
			Vector2 direction = new Vector2 (distance.x, distance.y).normalized;
			Debug.Log ("Ball collided");
		}*/
		//this.rigidbody2D.velocity += direction * -20f;
		//collider.rigidbody2D.velocity = new Vector2 (0f, 0f);
	}

	void OnCollisionEnter2D(Collision2D collison) {
		Debug.Log ("OnCollisionEnter2D");
		//Vector3 distance = collider.transform.position - this.transform.position;
		//Vector2 direction = new Vector2 (distance.x, distance.y).normalized;
		//this.rigidbody2D.velocity += direction * -20f;
		//collider.rigidbody2D.velocity = new Vector2 (0f, 0f);
	}
}
