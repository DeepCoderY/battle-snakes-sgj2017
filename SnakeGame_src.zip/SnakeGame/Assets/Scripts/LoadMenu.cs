﻿using UnityEngine;
using System.Collections;

public class LoadMenu : MonoBehaviour {

	private LevelManager mgr;

	// Use this for initialization
	void Start () {
		mgr = GetComponent<LevelManager> ();
		Invoke ("GoOn", 3f);
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void GoOn() {
		mgr.LoadNextLevel();
	}
}
