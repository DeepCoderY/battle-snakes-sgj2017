﻿using UnityEngine;
using System.Collections;

public class PickupCollider : MonoBehaviour {

	void OnTriggerEnter2D(Collider2D collider) {
		if (collider.gameObject.name.Contains("Head")) {
			//Debug.Log ("Bug picked up:" + collider.name);
			SnakeControll c = collider.gameObject.GetComponent<SnakeControll>();
			c.EatBug();
			Destroy(this.gameObject);
			Spawner.BugPicked();
		} 
	}
}
