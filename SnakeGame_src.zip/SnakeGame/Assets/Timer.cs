﻿using UnityEngine.UI;
using UnityEngine;
using System.Collections;

public class Timer : MonoBehaviour {

	public Text timer;
	public LevelManager mgr;
	public int roundTime = 120;
	private Snake[] snakes;
	private float startTime;

	// Use this for initialization
	void Start () {
		this.snakes = GameObject.FindObjectsOfType<Snake> ();
		this.timer.text = "1:59";
		this.startTime = Time.time;
	}
	
	// Update is called once per frame
	void Update () {
		float timer = this.roundTime - (Time.time - this.startTime); 
		int min = (int)(timer / 60.0f);
		int sec = ((int)timer % 60);
		string minSec = string.Format("{0}:{1}", min, sec.ToString("00"));
		this.timer.text = minSec;
		if (timer <= 0f) {
			// game ended
			int winnerId = -1;
			float maxScore = -1;
			foreach (Snake s in snakes) {
				if (s.GetHealth() > maxScore) {
					maxScore = s.GetHealth();
					winnerId = s.PlayerId;
				}
			}
			LevelManager.Winner = winnerId;
			mgr.LoadLevel("99_WinScreen");
		}
	}
}
