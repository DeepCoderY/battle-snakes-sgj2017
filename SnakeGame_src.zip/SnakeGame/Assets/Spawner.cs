﻿using UnityEngine;
using System.Collections;

public class Spawner : MonoBehaviour {

	private float nextPickup;
	private GameObject bugPrefab;
	private GameObject spikePrefab;

	private static int bugCount = 0;
	private static int maxBugs = 10;

	// Use this for initialization
	void Start () {
		this.bugPrefab = Resources.Load("Prefabs/Bug", typeof(GameObject)) as GameObject;
		this.spikePrefab = Resources.Load("Prefabs/Spike", typeof(GameObject)) as GameObject;
		for (int i = 0; i < 4; i++) {
			SpawnBug();
		}
		for (int i = 0; i < Random.Range(1,5); i++) {
			SpawnSpike();
		}
	}
	
	// Update is called once per frame
	void Update () {
		if (Time.time >= this.nextPickup) {
			SpawnBug();
		}
	}

	public static void BugPicked() {
		bugCount --;
		if (bugCount < 0) {
			bugCount = 0;
		}
	}

	void SpawnBug() {
		if (bugCount < maxBugs) {
			this.nextPickup = Time.time + Random.Range (1f, 2f);
			GameObject bug = Instantiate (this.bugPrefab) as GameObject;
			bug.AddComponent<PickupCollider> ();
			bug.transform.SetParent (this.transform);
			bug.transform.position = new Vector3 (Random.Range (-720f, 750f), Random.Range (-400f, 370f), 0f);
			bug.transform.eulerAngles = new Vector3(0f,0f, Random.Range(0f, 359f));
			bugCount++;
		}
	}

	void SpawnSpike() {
		GameObject spike = Instantiate (this.spikePrefab) as GameObject;
		spike.AddComponent<SpikeCollider>();
		spike.transform.SetParent (this.transform);
		spike.transform.position = new Vector3(Random.Range(-720f, 750f), Random.Range(-400f, 370f), 0f);
		spike.transform.eulerAngles = new Vector3(0f,0f, Random.Range(0f, 359f));
	}
}
