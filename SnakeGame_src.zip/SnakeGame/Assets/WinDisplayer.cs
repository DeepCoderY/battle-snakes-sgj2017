﻿using UnityEngine.UI;
using UnityEngine;
using System.Collections;

public class WinDisplayer : MonoBehaviour {

	public Text title;

	// Use this for initialization
	void Start () {
		this.title.text = "Player " + (LevelManager.Winner + 1) + " Won!";
		LevelManager.Winner = -1;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
